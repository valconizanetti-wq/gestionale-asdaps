# Test domande di iscrizione e voto CD (collaudo v0.30.3, aggiornata alla v0.30.4)

Lista di collaudo manuale su arco.valconi.it. Collaudo della v0.30.3
concluso il 30/09/2026: blocchi A–F superati, pulizia fatta. Copia viva,
con le spunte, nel documento Claude «Test domande di iscrizione e voto CD»;
questa copia nel repository e `claude/test-domande-iscrizione.md` nel
progetto vanno tenute uguali.
Per ogni prova fallita portare nella chat di debug: numero della prova, id
della domanda, cosa si è fatto, atteso, risultato, screenshot, righe di
`storage/logs/laravel.log` dell'orario.

## Preparazione
- Modalità test: `php artisan tinker --execute="App\Models\Impostazione::set('domande_modalita_test', true, 'boolean');"`
- CD di prova in `gl_governance_cd` (senza schermata, via SQL: vedi «CD di prova» sotto): Andrea Papini (Presidente), Massimo Papini, Paolo Zanetti (Segretario e Tesoriere), Luigi Tascio, tutti soci attivi con `valconi@usa.net`. Senza CD la votazione non si apre (causa della A6 del 29/09).
- Cron attivo (`deploy.md` §6, output su `/dev/null`); `php artisan domande:scadenze --prova` senza errori. Pagine anche a 375 px.
- Fuso orario: il gestionale salva le date in UTC (`config/app.php`), NOW() di MySQL è in ora italiana (2 ore avanti). Per questo le simulazioni usano un giorno in più del necessario.
- Simulare i giorni (N = id domanda), poi lanciare subito a mano `php artisan domande:scadenze` (il cron lo esegue solo una volta all'ora, al minuto 00):
  - sollecito: `UPDATE gl_domande SET created_at = NOW() - INTERVAL 4 DAY WHERE id = N;`
  - fine 5 giorni: `UPDATE gl_domande SET scadenza_cd = NOW() - INTERVAL 1 DAY WHERE id = N;` (non «1 MINUTE», per il fuso)
  - promemoria diniego (domanda «da rifiutare», diniego non ancora inviato): `UPDATE gl_domande SET esito_il = NOW() - INTERVAL 8 DAY, promemoria_diniego_il = NULL WHERE id = N;`
  - termine per la quota passato ma nel margine (non decade): `UPDATE gl_domande SET quota_scadenza = CURDATE() - INTERVAL 1 DAY WHERE id = N;`
  - decadenza (termine di 5 giorni + 5 di margine): `UPDATE gl_domande SET quota_scadenza = CURDATE() - INTERVAL 6 DAY WHERE id = N;`

## Reset tra un giro e l'altro (dati fittizi: si cancella tutto)
```sql
DELETE FROM gl_voti_cd;
DELETE FROM gl_email_log;
UPDATE gl_domande SET verbale_cd_id = NULL;
DELETE FROM gl_verbali WHERE tipo = 'cd_ammissione' OR domanda_id IS NOT NULL;
DELETE FROM gl_domande;
ALTER TABLE gl_voti_cd AUTO_INCREMENT = 1;
ALTER TABLE gl_email_log AUTO_INCREMENT = 1;
ALTER TABLE gl_domande AUTO_INCREMENT = 1;
```
Poi: `rm -rf storage/app/private/domande`, spostare `laravel.log`, `php artisan cache:clear` e le tre cache, modalità test accesa, finestra anonima nuova per ogni domanda. Il CD non si tocca.

## A. Modulo pubblico e annullamento
- A1 Adulto, telefono: dati dal CF, riepilogo, pagina «domanda inviata». Tendina del documento nello stile del sito. Nessun 429 con più giri avanti/modifica.
- A2 Minorenne, desktop: genitore + minore, email del minore vuota; quota socio giovane; email al genitore.
- A3 Errori: CF nel riquadro accanto al campo, alto come il campo, in rosso; sparisce correggendo; codice incompleto segnalato all'uscita dal campo. Email, obbligatori, consenso: messaggio accanto al campo, dati conservati.
- A4 Nome `[clicca](http://esempio.it)`: rifiutato.
- A5 Email «domanda ricevuta» col nuovo testo (ricezione, trasmissione al CD, esito per email, ricevuta in allegato, «puoi annullarla»): stile del sito, PDF allegato su carta intestata in una pagina (Compagnia Arcieri Castel Viscardo A.S.D., indirizzo pubblico, info@arciericastello.it · arciericastello.it), ore italiane, link di ritiro, niente antivirus.
- A6 Ritiro durante il voto (inviti già partiti): conferma; avviso ai consiglieri; link di voto chiusi.
- A6b Senza CD in carica: avviso «votazione non aperta» al Presidente/segreteria, una volta; inserito il CD, il comando orario apre la votazione; alla scadenza non viene accolta d'ufficio.
- A7 Ritiro di una domanda accolta: entro il termine per la quota si ritira; con termine passato (`quota_scadenza = CURDATE() - INTERVAL 1 DAY`) il link porta a «Iscrizione non annullabile»; dopo l'iscrizione (E6) stessa pagina con il rimando al recesso.
- A8 Riepilogo: link «Leggi lo statuto» e «Leggi l'informativa»; caselle spuntabili subito, senza aprire i testi (se aperti, l'ora compare in ricevuta); desktop: finestra sulla pagina; telefono: pagina del documento con «Torna alla domanda», al ritorno spunte conservate. /informativa-privacy e /statuto leggibili a 375 px; statuto e informativa 1.0; l'informativa riporta sede ufficiale e info@arciericastello.it.
- A9 (v0.30.4) Statuto pubblicato con le modifiche unite: su /statuto l'art. 6 dice «valida con l'invio del modulo» (c. 1), «assenso al tesseramento» del minore dai 14 anni (c. 3), «entro 5 giorni dalla sua presentazione» e «decide il Presidente» (c. 4), «disposto entro 5 giorni» (c. 6); l'art. 16.4 lett. d non dice più «quando l'esito non può più cambiare»; ci sono l'art. 24-bis e l'art. 16.7. La ricevuta di una domanda nuova riporta l'impronta del testo nuovo (diversa da quella delle domande di prova precedenti).

## B. Voto dei consiglieri
- B1 4 inviti, nome e link diversi.
- B2 Favorevole: «voto registrato»; il link non rivota.
- B3 Contrario con motivo di 19 caratteri o meno: errore; da 20 in su (es. 21): ok.
- B4 Token manomesso: «link non valido».
- B5 «Invia di nuovo» (area riservata → Domande → scheda della domanda → tabella dei voti, colonna azioni; solo votazione aperta, consigliere con email che non ha ancora votato, utente con permesso di modifica): arriva lo stesso link; il pulsante non c'è per chi ha votato.
- B6 Senza email (scheda socio di Luigi): avviso in scheda e al Presidente; conta come non votante. Da fare dopo C1 e C4, o rimettendo l'email.

## C. Esiti (una domanda per prova)
- C1 4 favorevoli: chiusa subito; esito «Accolta»; email di accoglimento col nuovo testo: quota, «bonifico da disporre entro il …» (5 giorni, statuto art. 6.6), bonifico a Compagnia Arcieri Castel Viscardo A.S.D., IBAN segnaposto, causale.
- C2 3 su 4 favorevoli: resta aperta; a scadenza accolta, verbale «alla scadenza del termine».
- C3 1 solo voto: a scadenza accolta d'ufficio (email, scheda, verbale).
- C4 3 contrari + 1 favorevole: «da rifiutare», email al Presidente (10 giorni); diniego ≥ 20 caratteri; richiedente riceve diniego con appello 30 giorni.
- C5 2–2 con il Presidente: prevale il suo voto (favorevole → accolta; contrario → da rifiutare).
- C6 Parità senza Presidente: serve un quinto consigliere di prova (Giulia Conti); 2–2, Andrea non vota, a scadenza «voti pari»; Presidente accoglie (accoglimento) o respinge con motivo (diniego). Per ultima.
- C7 Nessun pulsante di chiusura anticipata.

## D. Scadenze
- D1 Sollecito al 3° giorno solo a chi non ha votato, una volta (comando lanciato due volte).
- D2 Promemoria diniego dopo 7 giorni, uno solo.
- D3 Decadenza per quota non versata: con termine passato da 1 giorno la domanda resta accolta e la scheda dice «Termine passato il … · decade il …»; con 6 giorni decade.
- D4 `--prova`: riepilogo, nessuna modifica né email.
- D5 Il cron chiude da solo una votazione scaduta.

## E. Area riservata
- E1 Elenco: filtri, anno, ricerca, riquadri coerenti, 375 px.
- E2 Scheda per ogni stato: voti, motivazioni, cronologia, azioni giuste.
- E3 Permessi: sola lettura senza pulsanti; non Presidente senza decisione e diniego.
- E4 Bozza di verbale (scheda della domanda → «Apri il verbale») per C1, C3, C4, C6: esito, voto di ciascun consigliere con data e ora, motivazioni, decisione del Presidente. Stato «Bozza»: approvazione, numero e PDF arriveranno con il modulo Verbali.
- E5 Ricevuta PDF (carta intestata, una pagina, statuto e informativa aperti il…).
- E6 Iscrizione nel libro soci: bloccata sulle domande di prova; con `is_test = 0`: socio, rinnovo, Prima Nota QUOTE, email di benvenuto; nella scheda del socio, voce privacy «Domanda online n. X del …» con i pulsanti Ricevuta e Domanda; poi pulire a mano.
- E7 Promozione ottobre–dicembre (dal 1° ottobre): quota anno dopo, valida al 31/12 dell'anno successivo; per domanda e generale.
- E8 Eliminazione domanda di prova; pulsante assente sulle vere.

## F. Email e pulizia
- F1 Tutte le email: mittente, stile, link, antivirus, telefono.
- F2 `gl_email_log`: tutto «inviata».
- F3 Nessun errore nuovo in `laravel.log`.
- F4 Pulizia: domande di prova, quinto consigliere, email di Luigi, modalità test spenta (`... set('domande_modalita_test', false, 'boolean');`).

## CD di prova (SQL)
Controllo dei soci:
```sql
SELECT id, nome, cognome, email, stato FROM gl_soci
WHERE (nome, cognome) IN (('Andrea','Papini'),('Massimo','Papini'),('Paolo','Zanetti'),('Luigi','Tascio'));
```
Inserimento nel CD (dopo aver verificato che ci siano tutti e quattro):
```sql
INSERT INTO gl_governance_cd (socio_id, carica, data_inizio_mandato, in_carica, created_at, updated_at)
SELECT id,
       CASE WHEN nome = 'Andrea' AND cognome = 'Papini' THEN 'Presidente'
            WHEN nome = 'Paolo' AND cognome = 'Zanetti' THEN 'Segretario e Tesoriere'
            ELSE 'Consigliere' END,
       CURDATE(), 1, NOW(), NOW()
FROM gl_soci
WHERE (nome, cognome) IN (('Andrea','Papini'),('Massimo','Papini'),('Paolo','Zanetti'),('Luigi','Tascio'))
  AND stato = 'attivo';
```
