# Bootstrap — Gestionale ASD, dopo la v0.30.4 (statuto unito, 04/10/2026)

## Contesto
Come in `bootstrap-voto-cd.md` (progetto, ambienti, regole di lavoro,
deploy §5). In più: dalla v0.30.0 serve il cron di cPanel
`php artisan schedule:run` ogni minuto (`deploy.md` §6).

## Stato alla chiusura (29/09/2026)
- v0.30.0 consegnata: domanda valida con l'invio, voto del CD dal link
  personale, esiti, email nello stile del sito, area riservata
  `/domande`, bozza di verbale, iscrizione nel libro soci con rinnovo e
  Prima Nota, promozione di ottobre–dicembre, comando orario
  `domande:scadenze`. Scheda: `domande-iscrizione.md` (§3 e §7).
- CD di prova: Andrea Papini (Presidente), Massimo Papini, Paolo Zanetti
  (Segretario e Tesoriere), Luigi Tascio, tutti `valconi@usa.net`.
- IBAN: ancora segnaposto `IT XX …` (scheda Associazione vuota).
- Posta: DKIM e DMARC di `valconi.it` sistemati il 29/09/2026.
- Statuto (v0.30.4, 04/10/2026): il testo pubblicato
  (`resources/content/statuto/1.0.md`, pagina `/statuto`) è la bozza 1.1
  completa: artt. 6.1, 6.4, 6.6 (quota disposta entro 5 giorni) e 16.4
  lett. d come in `statuto-modifiche-v1.1.md`, più le clausole CSEN (artt.
  6.3, 11.3, 14, 16.7, 22.5, 24-bis, 31). Numerato 1.0 fino all'apertura.
  Bozza 1.1 (md, docx, `ACV-Statuto-1.1.pdf`) aggiornata all'art. 6.6. Da
  chiedere al CSEN: esclusione in Assemblea vincolante? accoglimento
  d'ufficio e voto telematico accettati?

## Prossimo obiettivo
1. Assenso del minore dai 14 anni al tesseramento (art. 16 D.Lgs.
   36/2021, statuto v1.1 art. 6.3): nel modulo di domanda, quando il CF
   indica almeno 14 anni, dichiarazione di assenso del minore; salvarla in
   `gl_domande` con data, riportarla in ricevuta, riepilogo, scheda della
   domanda e verbale. Tavole sulla tela prima del codice.
2. Link personale per il consenso privacy dei soci senza domanda online
   (`soci.md`, `domande-iscrizione.md` §6): stessa pagina dell'informativa,
   token come per il voto, registrazione in `gl_soci.privacy_*`.

## Collaudo (29–30/09/2026)
- v0.30.3 consegnata (ZIP cumulativo con la v0.30.2; dettaglio in
  `domande-iscrizione.md` §7 e in `LEGGIMI-v0.30.3.txt`). Collaudo della lista
  `test-domande-iscrizione.md` concluso il 30/09/2026: blocchi A–F superati,
  pulizia fatta (simulazioni con un giorno in più per il fuso: gestionale
  in UTC, NOW() di MySQL in ora italiana). Cron verificato: il comando
   orario gira al minuto 00. Sul server, se non già fatto: riga del cron
  di cPanel riportata a `>> /dev/null 2>&1` e `storage/logs/cron.log`
  cancellato (`deploy.md` §6).
- Decisioni del 30/09: quota con bonifico disposto entro 5 giorni
  dall'accoglimento, decadenza dopo altri 5 di margine; ritiro di una
  domanda accolta solo fino al termine per la quota; dichiarazioni su
  statuto e informativa senza obbligo di aprirli (l'ora del clic su "Invia"
  vale per le dichiarazioni); denominazione "Compagnia Arcieri Castel
  Viscardo A.S.D."; indirizzo pubblico e ufficiale, email
  info@arciericastello.it e sito arciericastello.it in `config/sito.php`;
  informativa e statuto corretti sul posto alla versione 1.0 fino
  all'apertura.
- Modulo del socio rifatto: righe compatte, dati di nascita dal codice
  fiscale, residenza/email/telefono obbligatori, telefono unico (tolto il
  cellulare), genitore completo per i minorenni (`soci.md`).
- Sul server: CD di prova inserito via SQL; a ogni deploy
  `php artisan optimize:clear` prima delle cache (`deploy.md` §5); scheda
  Associazione da aggiornare con info@arciericastello.it quando la casella
  riceve posta.
- `docs/specifiche/domande-iscrizione.md` è una copia identica di
  `docs/domande-iscrizione.md`: si aggiornano insieme.
- Lista di collaudo: `docs/test/test-domande-iscrizione.md` e
  `claude/test-domande-iscrizione.md` nel progetto, uguali (v0.30.4, prova
  A9 sullo statuto pubblicato).

## Punti aperti
- Modulo Verbali (libro dei verbali): oggi esiste solo la bozza
  automatica del verbale di ammissione per ogni domanda (`VerbaleAmmissione`,
  "Apri il verbale" nella scheda); mancano approvazione, numerazione, firma,
  PDF ed elenco dei verbali. Finché non c'è, i verbali restano in bozza.
- Statuto: al momento dell'adozione decidere se pubblicarlo come 1.0
  (prima versione pubblica) o 1.1. Lo statuto pubblicato prevede già
  l'assenso del minore dai 14 anni (art. 6.3), che il modulo non chiede
  ancora (prossimo obiettivo, punto 1).
- Fuso orario: `config/app.php` ha `'timezone' => 'UTC'` scritto a mano,
  quindi `APP_TIMEZONE=Europe/Rome` del `.env` non ha effetto; termini e
  minore età si calcolano in UTC (`domande-iscrizione.md` §7, v0.30.4). Da
  decidere se correggere (`env('APP_TIMEZONE', 'UTC')`).
- Azzeramento finale prima dell'apertura al pubblico (Paolo, 29/09/2026:
  oggi è tutto in prova): domande, voti, email, verbali, soci, rinnovi e
  movimenti di prova, registro di audit; modalità test spenta. Procedura
  da scrivere quando ci si arriva. Fino ad allora informativa e statuto si
  correggono sul posto con il numero di versione dell'avvio (1.0), senza
  versioni intermedie (`domande-iscrizione.md` §7, v0.30.3).
- Informativa: segnaposto di hosting (punto 4, SupportHost: datacenter UE
  e DPA) e del consulente fiscale (punto 5) da sostituire.
- Recesso dal link della ricevuta dopo l'iscrizione, al posto di "Domanda
  già decisa" (`domande-iscrizione.md` §7, v0.30.3): dimissioni al CD per
  email (statuto art. 9), dati della domanda conservati.
- Pagina Impostazioni (quote, promozione, versioni dei testi).
- Numero di ricevuta della prima quota (modulo Rinnovi quota).
- Richiesta di riunione da un terzo dei consiglieri (art. 16.4 lett. f).
