# Statuto della Compagnia Arcieri Castel Viscardo A.S.D.

Versione 1.1 — bozza del 29 settembre 2026, aggiornata il 4 ottobre 2026, da approvare in Assemblea straordinaria

## Titolo I — Denominazione, sede, scopo

### Art. 1 – Denominazione, sede e durata

1. È costituita, ai sensi degli artt. 36 e seguenti del Codice civile e del D.Lgs. 28 febbraio 2021, n. 36, l'associazione sportiva dilettantistica senza scopo di lucro denominata "Compagnia Arcieri Castel Viscardo – Associazione Sportiva Dilettantistica", in forma abbreviata "Compagnia Arcieri Castel Viscardo A.S.D." (di seguito "Associazione"). La denominazione, completa della dicitura "associazione sportiva dilettantistica", è usata in ogni atto e comunicazione rivolta a terzi.
2. L'Associazione ha sede legale presso il Campo di tiro "Franco Cortignani", località Macchietto, Viceno, 05014 Castel Viscardo (TR). Il trasferimento della sede all'interno dello stesso Comune è deliberato dal Consiglio Direttivo e non costituisce modifica dello statuto.
3. La durata dell'Associazione è illimitata.

### Art. 2 – Ordinamento sportivo e affiliazione

1. L'Associazione si conforma alle norme e alle direttive del CIO, del CONI e agli statuti e regolamenti delle Federazioni sportive nazionali, delle Discipline sportive associate e degli Enti di promozione sportiva cui si affilia.
2. L'affiliazione è deliberata dal Consiglio Direttivo. L'Associazione si affilia al CSEN – Centro Sportivo Educativo Nazionale, Ente di promozione sportiva riconosciuto dal CONI, e può affiliarsi ad altri enti dell'ordinamento sportivo.
3. L'Associazione e i suoi soci si impegnano a rispettare gli statuti, i regolamenti e i provvedimenti disciplinari degli organi competenti degli enti cui l'Associazione è affiliata, nonché la normativa antidoping.
4. L'Associazione è iscritta nel Registro nazionale delle attività sportive dilettantistiche (RASD) secondo le modalità previste dal D.Lgs. 28 febbraio 2021, n. 39.

### Art. 3 – Scopo e oggetto sociale

1. L'Associazione è apolitica e aconfessionale, ha struttura democratica e non discrimina in base a sesso, origine, religione, opinioni, condizioni personali e sociali.
2. L'Associazione ha per oggetto l'esercizio in via stabile e principale dell'organizzazione e gestione di attività sportive dilettantistiche, in particolare del tiro con l'arco in tutte le sue specialità e delle discipline collegate, comprese la formazione, la didattica, la preparazione e l'assistenza all'attività sportiva dilettantistica.
3. Per realizzare il proprio oggetto l'Associazione, tra l'altro:
   1. organizza corsi, allenamenti, gare, manifestazioni ed eventi promozionali;
   2. partecipa a competizioni e attività organizzate dagli enti di affiliazione;
   3. gestisce impianti e attrezzature sportive, anche in convenzione con enti pubblici e privati;
   4. promuove la formazione di tecnici, istruttori e ufficiali di gara.
4. L'Associazione può esercitare attività diverse da quelle istituzionali, purché secondarie e strumentali rispetto a queste, nei limiti e secondo i criteri dell'art. 9 del D.Lgs. 36/2021 e dei relativi decreti attuativi. Le attività diverse sono individuate dal Consiglio Direttivo e comprendono la raccolta fondi, le sponsorizzazioni e la gestione di un punto di ristoro per i soci.
5. L'Associazione può aderire ad altri enti e stipulare convenzioni con enti pubblici e privati per il perseguimento del proprio oggetto.

### Art. 4 – Assenza di scopo di lucro

1. Gli eventuali utili e avanzi di gestione sono destinati esclusivamente allo svolgimento dell'attività statutaria o all'incremento del patrimonio.
2. È vietata la distribuzione, anche indiretta, di utili, avanzi di gestione, fondi, riserve o capitale a soci, amministratori, componenti degli organi sociali, volontari e collaboratori, anche in caso di recesso o di ogni altra ipotesi di scioglimento individuale del rapporto associativo, salvo che la destinazione o la distribuzione siano imposte dalla legge.

## Titolo II — Soci

### Art. 5 – Soci e categorie

1. Il numero dei soci è illimitato. Possono essere soci le persone fisiche che condividono le finalità dell'Associazione e ne accettano lo statuto e i regolamenti.
2. I soci appartengono alle seguenti categorie:
   1. **soci fondatori**: coloro che hanno sottoscritto l'atto costitutivo;
   2. **soci ordinari**: le persone maggiorenni ammesse secondo l'art. 6;
   3. **soci giovani**: le persone minorenni ammesse secondo l'art. 6. Al compimento del diciottesimo anno di età il socio giovane diventa socio ordinario senza bisogno di nuova domanda; la quota della nuova categoria si applica dall'anno sociale successivo.
3. Il rapporto associativo è disciplinato in modo uniforme per tutti i soci ed è esclusa ogni forma di partecipazione temporanea. Le categorie non comportano differenze di diritti, salvo quanto previsto per i minorenni dall'art. 7.
4. Il Consiglio Direttivo fissa ogni anno la quota associativa per ciascuna categoria. La quota è intrasmissibile, non rivalutabile e non è restituita in nessun caso.

### Art. 6 – Ammissione

1. Chi intende diventare socio presenta domanda al Consiglio Direttivo in forma scritta, anche per via telematica tramite il modulo pubblicato dall'Associazione. La domanda telematica è valida con l'invio del modulo completo delle dichiarazioni richieste; l'Associazione conserva la prova dell'invio (data, ora e dati tecnici) e trasmette all'indirizzo di posta elettronica indicato una ricevuta della domanda, con il collegamento per ritirarla.
2. La domanda contiene i dati anagrafici, il codice fiscale, la residenza e l'indirizzo di posta elettronica del richiedente, la dichiarazione di conoscere e accettare lo statuto e i regolamenti, la richiesta di tesseramento all'ente di affiliazione e la presa visione dell'informativa sul trattamento dei dati personali.
3. La domanda del minorenne è presentata da chi esercita la responsabilità genitoriale, che rappresenta il minore nei confronti dell'Associazione e risponde delle obbligazioni che ne derivano. Il minore che ha compiuto quattordici anni presta personalmente il proprio assenso al tesseramento, che altrimenti non può avvenire (art. 16 del D.Lgs. 36/2021).
4. Il Consiglio Direttivo delibera sulla domanda entro 5 giorni dalla sua presentazione, anche con la procedura telematica dell'art. 16. Se alla scadenza del termine non ha votato la maggioranza dei componenti, la domanda si intende accolta d'ufficio. Se i voti espressi sono pari e il Presidente non ha votato, decide il Presidente. Il verbale riporta l'esito di ciascuna domanda, il voto di ciascun consigliere, l'eventuale accoglimento d'ufficio e l'eventuale decisione del Presidente.
5. Il diniego deve essere motivato ed è comunicato al richiedente entro 10 giorni dalla delibera. Entro 30 giorni dalla comunicazione il richiedente può presentare appello all'Assemblea, che decide nella prima riunione utile.
6. L'accoglimento è comunicato al richiedente. L'ammissione si perfeziona con il versamento della quota associativa, disposto entro 5 giorni dalla comunicazione, e con l'iscrizione nel libro dei soci. Se la quota non è versata nel termine, la domanda decade.

### Art. 7 – Diritti dei soci

1. Tutti i soci hanno diritto di:
   1. partecipare alle attività promosse dall'Associazione e frequentarne gli impianti, secondo i regolamenti;
   2. partecipare alle gare e alle manifestazioni nell'ambito degli enti di affiliazione, secondo le relative norme;
   3. essere informati sulla vita dell'Associazione e consultare i libri sociali, con richiesta al Consiglio Direttivo, che ne consente l'accesso entro 15 giorni.
2. I soci maggiorenni in regola con il versamento della quota hanno diritto di voto in Assemblea, anche per l'approvazione e la modifica dello statuto e dei regolamenti e per la nomina degli organi, e sono eleggibili alle cariche sociali alle condizioni dell'art. 11.
3. I soci minorenni non hanno diritto di voto. Chi esercita la responsabilità genitoriale riceve la convocazione dell'Assemblea e può assistervi senza diritto di parola né di voto. Il socio che diventa maggiorenne esercita il diritto di voto dalla prima Assemblea successiva.

### Art. 8 – Doveri dei soci

1. I soci sono tenuti a:
   1. osservare lo statuto, i regolamenti e le deliberazioni degli organi sociali;
   2. versare la quota associativa annuale **entro il 31 gennaio** di ciascun anno sociale; per i nuovi soci vale il termine dell'art. 6, comma 6;
   3. tenere una condotta improntata a lealtà, probità e correttezza sportiva, astenendosi da ogni illecito sportivo e da comportamenti lesivi della dignità e del prestigio dell'Associazione;
   4. rispettare le regole di sicurezza del campo di tiro e il codice di condotta dell'art. 28;
   5. comunicare le variazioni dei propri dati, in particolare dell'indirizzo di posta elettronica.

### Art. 9 – Perdita della qualifica di socio

1. La qualifica di socio si perde per:
   1. **recesso**: dimissioni comunicate per iscritto al Consiglio Direttivo, anche per posta elettronica, efficaci dalla ricezione;
   2. **decadenza per morosità**: se la quota non è versata entro il 31 gennaio, il socio non può esercitare il diritto di voto fino al versamento; trascorsi tre mesi dalla scadenza senza versamento, il socio decade. Il Consiglio Direttivo prende atto della decadenza, la annota nel libro dei soci e la comunica all'interessato;
   3. **esclusione**: deliberata dal Consiglio Direttivo a maggioranza assoluta dei componenti nei confronti del socio che violi gravemente lo statuto, i regolamenti, il codice di condotta o le deliberazioni degli organi, o che con la sua condotta arrechi danno materiale o morale all'Associazione. La delibera è preceduta dalla contestazione scritta degli addebiti, con un termine di almeno 10 giorni per le difese, ed è comunicata per iscritto;
   4. **decesso**.
2. Contro l'esclusione il socio può ricorrere all'Assemblea entro 30 giorni dalla comunicazione. L'Assemblea decide nella prima riunione utile, dopo aver sentito l'interessato. Fino alla decisione il socio è sospeso da ogni diritto; l'esclusione è annotata nel libro dei soci quando diventa definitiva.
3. La perdita della qualifica comporta la decadenza da ogni carica e non dà diritto alla restituzione di quanto versato. Il socio escluso non può essere riammesso.

## Titolo III — Organi

### Art. 10 – Organi e cariche

1. Sono organi dell'Associazione l'Assemblea dei soci, il Consiglio Direttivo, il Presidente e, se nominato, l'Organo di controllo.
2. Le cariche sociali sono elettive e gratuite, salvo il rimborso delle spese effettivamente sostenute e documentate per l'incarico.

### Art. 11 – Requisiti per le cariche e incompatibilità

1. Possono ricoprire cariche sociali i soci maggiorenni, in regola con il versamento della quota, che non abbiano riportato condanne passate in giudicato per delitti non colposi e che non abbiano subito, da parte del CONI o degli enti dell'ordinamento sportivo, squalifiche o inibizioni per periodi complessivamente **superiori** a un anno.
2. Il Presidente non può ricoprire alcuna carica in altre associazioni o società sportive dilettantistiche nell'ambito della medesima Federazione sportiva nazionale, Disciplina sportiva associata o Ente di promozione sportiva, ai sensi dell'art. 11 del D.Lgs. 36/2021 nel testo vigente. Restano ferme le ulteriori incompatibilità previste dalla legge o dagli enti di affiliazione.
3. Non può essere eletto consigliere e, se eletto, decade chi si trova nelle condizioni previste dall'art. 2382 del Codice civile.

### Art. 12 – Assemblea: composizione e convocazione

1. L'Assemblea è l'organo sovrano dell'Associazione ed è composta da tutti i soci. Ogni socio con diritto di voto dispone di un voto. **Non sono ammesse deleghe.**
2. L'Assemblea è convocata dal Presidente, su delibera del Consiglio Direttivo:
   1. almeno una volta all'anno, entro quattro mesi dalla chiusura dell'esercizio, per l'approvazione del rendiconto;
   2. quando il Consiglio Direttivo lo ritiene opportuno;
   3. quando ne fa richiesta motivata almeno un decimo dei soci con diritto di voto; in tal caso la convocazione avviene entro 30 giorni dalla richiesta.
3. L'avviso di convocazione indica data, ora e luogo della prima e della seconda convocazione, tra le quali deve intercorrere almeno un'ora, l'ordine del giorno e, se prevista, la modalità di partecipazione a distanza. È inviato a ciascun socio all'indirizzo di posta elettronica risultante dal libro dei soci, o per posta ordinaria a chi non ne dispone, ed è affisso presso la sede almeno 10 giorni prima della riunione, 15 giorni per l'Assemblea straordinaria.

### Art. 13 – Svolgimento dell'Assemblea

1. L'Assemblea è presieduta dal Presidente o, in sua assenza, dal Vicepresidente o da un socio eletto dai presenti. Il presidente dell'Assemblea nomina un segretario verbalizzante e, se occorre, due scrutatori scelti tra soci che non siano candidati.
2. I soci possono partecipare e votare a distanza, mediante strumenti di comunicazione che consentano di identificarli e di seguire la discussione e intervenire in tempo reale. La partecipazione a distanza è ammessa anche per l'Assemblea che elegge le cariche sociali.
3. Le votazioni sono palesi, per alzata di mano o per appello nominale. Le elezioni delle cariche sociali si svolgono sempre a scrutinio segreto; le altre votazioni che riguardano persone si svolgono a scrutinio segreto se lo chiede almeno un decimo dei presenti. Lo scrutinio segreto può svolgersi anche con strumenti telematici che garantiscano l'identificazione dei votanti, l'unicità del voto e la sua segretezza.
4. Di ogni Assemblea è redatto un verbale, sottoscritto dal presidente e dal segretario dell'Assemblea, trascritto nel libro dei verbali delle Assemblee e messo a disposizione dei soci con le modalità dell'art. 26.

### Art. 14 – Assemblea ordinaria e straordinaria

1. L'Assemblea ordinaria:
   1. approva il rendiconto economico-finanziario;
   2. elegge il Presidente e i componenti del Consiglio Direttivo, fissandone il numero;
   3. decide se nominare l'Organo di controllo e ne elegge i componenti;
   4. approva i regolamenti proposti dal Consiglio Direttivo;
   5. decide sugli appelli contro il diniego di ammissione e sui ricorsi contro l'esclusione;
   6. delibera sulla responsabilità dei componenti degli organi sociali e promuove l'azione di responsabilità nei loro confronti;
   7. delibera sugli altri argomenti sottoposti dal Consiglio Direttivo.
2. L'Assemblea ordinaria è validamente costituita in prima convocazione con la presenza della metà più uno dei soci con diritto di voto e in seconda convocazione qualunque sia il numero dei presenti. Delibera a maggioranza dei voti espressi.
3. L'Assemblea straordinaria delibera sulle modifiche dello statuto, sulla trasformazione, fusione, scissione o scioglimento dell'Associazione e sugli atti relativi a diritti reali immobiliari.
4. Per le modifiche dello statuto l'Assemblea straordinaria è validamente costituita in prima convocazione con la presenza della metà più uno dei soci con diritto di voto e in seconda convocazione con la presenza di almeno un terzo di essi, e delibera con il voto favorevole dei due terzi dei presenti.
5. La trasformazione, la fusione, la scissione e lo scioglimento dell'Associazione sono deliberati con il voto favorevole di almeno tre quarti dei soci con diritto di voto.

### Art. 15 – Consiglio Direttivo: composizione

1. Il Consiglio Direttivo è composto da un minimo di tre a un massimo di cinque membri, compreso il Presidente, secondo il numero fissato dall'Assemblea. Dura in carica **quattro anni** e i suoi membri sono rieleggibili.
2. Il Consiglio Direttivo nomina al proprio interno il Vicepresidente, il Segretario e il Tesoriere. Le funzioni di Segretario e Tesoriere possono essere attribuite alla stessa persona.
3. Il consigliere che cessa dalla carica è sostituito dal primo dei non eletti, se esiste; altrimenti il Consiglio prosegue fino alla prima Assemblea utile, che provvede alla sostituzione. Il sostituto resta in carica fino alla scadenza del Consiglio.
4. Se viene meno la maggioranza dei consiglieri, l'intero Consiglio decade. Il Presidente, o in sua mancanza il Vicepresidente o il consigliere più anziano di età, convoca entro 30 giorni l'Assemblea per il rinnovo; nel frattempo il Consiglio decaduto cura soltanto l'ordinaria amministrazione.
5. Decade il consigliere che, senza giustificato motivo, non partecipa a tre riunioni consecutive.

### Art. 16 – Consiglio Direttivo: riunioni e deliberazioni

1. Il Consiglio Direttivo si riunisce almeno due volte all'anno e ogni volta che il Presidente lo ritiene opportuno o che ne fa richiesta almeno un terzo dei consiglieri. La convocazione, con l'ordine del giorno, è inviata per posta elettronica almeno tre giorni prima; nei casi urgenti almeno 24 ore prima.
2. Le riunioni possono svolgersi anche in videoconferenza, purché sia possibile identificare i partecipanti e consentire loro di intervenire e votare in tempo reale.
3. Il Consiglio è validamente costituito con la presenza della maggioranza dei componenti e delibera a maggioranza dei presenti. In caso di parità prevale il voto del Presidente.
4. **Deliberazione telematica.** Su iniziativa del Presidente, il Consiglio può deliberare anche senza riunione, mediante consultazione telematica:
   1. ogni consigliere riceve all'indirizzo di posta elettronica registrato la proposta di delibera, la documentazione e un collegamento personale e non cedibile per esprimere il voto entro un termine non inferiore a tre giorni; per l'ammissione di nuovi soci il termine è quello dell'art. 6, comma 4;
   2. il voto contrario all'ammissione di un nuovo socio deve essere motivato;
   3. la delibera è adottata se hanno votato almeno la maggioranza dei componenti e se ottiene la maggioranza dei voti espressi; in caso di parità prevale il voto del Presidente;
   4. la consultazione si chiude alla scadenza del termine, o prima quando tutti hanno votato;
   5. per ogni voto sono registrati data, ora e identificativo del collegamento usato;
   6. se almeno un terzo dei consiglieri lo chiede entro il termine, la proposta è discussa in riunione.
5. La consultazione telematica non può essere usata per la proposta del rendiconto né per l'esclusione di un socio.
6. Di ogni riunione e consultazione telematica è redatto un verbale, con il voto di ciascun consigliere, sottoscritto dal Presidente e dal Segretario e trascritto nel libro dei verbali del Consiglio Direttivo.
7. Al conflitto di interessi dei consiglieri si applica l'art. 2475-ter del Codice civile. Il consigliere in conflitto lo dichiara e non partecipa alla deliberazione.

### Art. 17 – Consiglio Direttivo: compiti

1. Il Consiglio Direttivo ha tutti i poteri di ordinaria e straordinaria amministrazione non riservati all'Assemblea. In particolare:
   1. attua le finalità statutarie e le deliberazioni dell'Assemblea;
   2. delibera sull'ammissione e sull'esclusione dei soci e prende atto delle decadenze;
   3. fissa le quote associative annuali per ciascuna categoria;
   4. redige il rendiconto economico-finanziario da sottoporre all'Assemblea;
   5. delibera le affiliazioni e i tesseramenti;
   6. predispone i regolamenti da sottoporre all'Assemblea;
   7. delibera le tipologie di spesa e le attività per cui sono ammessi i rimborsi ai volontari;
   8. nomina il responsabile per la tutela dei tesserati dell'art. 28 e adotta i modelli e il codice di condotta ivi previsti;
   9. nomina tecnici e istruttori e può affidare a soci non consiglieri incarichi specifici.

### Art. 18 – Presidente

1. Il Presidente è eletto dall'Assemblea insieme al Consiglio Direttivo e dura in carica quattro anni. Ha la rappresentanza legale e la firma dell'Associazione di fronte a terzi e in giudizio.
2. Convoca e presiede l'Assemblea e il Consiglio Direttivo e vigila sull'esecuzione delle deliberazioni. Nei casi di urgenza può adottare i provvedimenti di competenza del Consiglio, che li ratifica nella prima riunione utile.
3. In caso di assenza o impedimento è sostituito dal Vicepresidente. Se il Presidente cessa dalla carica, il Vicepresidente ne esercita le funzioni fino all'elezione del nuovo Presidente, da tenersi nella prima Assemblea utile.

### Art. 19 – Segretario e Tesoriere

1. Il Segretario redige i verbali delle riunioni del Consiglio Direttivo, cura la tenuta del libro dei soci e dei libri dei verbali e la corrispondenza.
2. Il Tesoriere cura la gestione contabile e amministrativa, gli incassi e i pagamenti deliberati, gli adempimenti fiscali e predispone, con il Consiglio, il rendiconto annuale.

### Art. 20 – Organo di controllo

1. L'Assemblea può nominare un Organo di controllo, monocratico o collegiale di tre membri, scelti anche tra non soci e comunque al di fuori del Consiglio Direttivo. L'Organo resta in carica per la durata del Consiglio Direttivo.
2. L'Organo di controllo vigila sull'osservanza della legge e dello statuto e sulla regolarità della contabilità, e redige una relazione sul rendiconto annuale.

## Titolo IV — Patrimonio, rendiconto, libri sociali

### Art. 21 – Patrimonio ed entrate

1. Il patrimonio dell'Associazione è costituito dai beni mobili e immobili che le pervengono a qualsiasi titolo e dagli eventuali fondi di riserva.
2. Le entrate sono costituite da:
   1. quote associative e corrispettivi specifici versati dai soci per le attività istituzionali;
   2. contributi ed erogazioni liberali di privati ed enti pubblici;
   3. proventi delle attività diverse e commerciali, comprese le sponsorizzazioni;
   4. ogni altra entrata compatibile con le finalità dell'Associazione.
3. Il patrimonio è utilizzato esclusivamente per lo svolgimento dell'attività statutaria.

### Art. 22 – Esercizio sociale e rendiconto

1. L'anno sociale e l'esercizio finanziario vanno dal 1° gennaio al 31 dicembre.
2. Il Consiglio Direttivo redige il rendiconto economico-finanziario dell'esercizio, distinguendo le entrate e le uscite delle attività istituzionali da quelle delle attività diverse e commerciali, e lo sottopone all'approvazione dell'Assemblea entro quattro mesi dalla chiusura dell'esercizio, ovvero entro sei mesi quando particolari esigenze lo richiedono.
3. Il rendiconto è depositato presso la sede e messo a disposizione dei soci, anche per via telematica, almeno 15 giorni prima dell'Assemblea che lo approva.
4. Per ogni raccolta pubblica di fondi svolta in occasione di celebrazioni, ricorrenze o campagne di sensibilizzazione è redatto, entro lo stesso termine, un rendiconto separato delle relative entrate e spese.
5. Il Consiglio Direttivo documenta il carattere secondario e strumentale delle attività diverse dell'art. 3, comma 4, nella relazione al rendiconto o, se il rendiconto è redatto per cassa, in un'annotazione in calce allo stesso.

### Art. 23 – Libri sociali

1. L'Associazione tiene il libro dei soci, il libro dei verbali delle Assemblee e il libro dei verbali del Consiglio Direttivo, e gli altri registri previsti dalla legge.
2. I libri possono essere tenuti in formato elettronico, con modalità che ne garantiscano l'integrità, la conservazione e la tracciabilità di ogni modifica.
3. I soci possono consultare i libri sociali secondo l'art. 7.

## Titolo V — Norme generali e finali

### Art. 24 – Volontari

1. L'Associazione si avvale prevalentemente dell'attività personale, spontanea e gratuita dei propri soci e di volontari, ai sensi dell'art. 29 del D.Lgs. 36/2021.
2. Ai volontari possono essere rimborsate soltanto le spese sostenute per l'attività, nei limiti e alle condizioni previsti dalla legge e dalle delibere del Consiglio Direttivo.
3. L'attività di volontario è incompatibile con qualsiasi rapporto di lavoro retribuito con l'Associazione. L'Associazione assicura i volontari per la responsabilità civile verso terzi, come previsto dalla legge.

### Art. 24-bis – Lavoratori sportivi

1. L'Associazione può avvalersi di lavoratori sportivi, anche soci, con i rapporti e alle condizioni previsti dagli artt. 25 e seguenti del D.Lgs. 36/2021; ai rapporti di collaborazione coordinata e continuativa di carattere amministrativo-gestionale si applica l'art. 37 del medesimo decreto.
2. I compensi sono deliberati dal Consiglio Direttivo nel rispetto dei limiti di legge e del divieto di distribuzione indiretta di utili dell'art. 4.

### Art. 25 – Regolamenti

1. Le norme di funzionamento non previste dallo statuto, compresi l'uso del campo di tiro e le regole di sicurezza, sono stabilite da regolamenti predisposti dal Consiglio Direttivo e approvati dall'Assemblea. I regolamenti non possono contrastare con lo statuto.

### Art. 26 – Comunicazioni ai soci

1. Le comunicazioni dell'Associazione ai soci, comprese le convocazioni, sono validamente effettuate all'indirizzo di posta elettronica indicato dal socio e risultante dal libro dei soci; per i soci minorenni, all'indirizzo di chi esercita la responsabilità genitoriale.
2. I verbali delle Assemblee, i rendiconti e le deliberazioni di interesse generale sono messi a disposizione dei soci presso la sede e per via telematica.

### Art. 27 – Dati personali

1. L'Associazione tratta i dati personali dei soci e dei richiedenti nel rispetto del Regolamento (UE) 2016/679 e della normativa nazionale, fornendo l'informativa al momento della raccolta.

### Art. 28 – Tutela dei minori e prevenzione degli abusi

1. L'Associazione adotta, nei termini di legge e secondo le linee guida degli enti di affiliazione, i modelli organizzativi e di controllo e il codice di condotta previsti dall'art. 16 del D.Lgs. 39/2021, per la tutela dei tesserati, in particolare dei minori, da abusi, violenze e discriminazioni.
2. Il Consiglio Direttivo nomina un responsabile per la protezione dei tesserati da abusi, violenze e discriminazioni, e ne rende noti il nominativo e i recapiti.
3. Soci, tecnici e volontari sono tenuti a rispettare il codice di condotta. La sua violazione costituisce grave inadempimento ai fini dell'art. 9.

### Art. 29 – Scioglimento

1. Lo scioglimento è deliberato dall'Assemblea straordinaria secondo l'art. 14, comma 5. L'Assemblea nomina uno o più liquidatori.
2. Il patrimonio residuo è devoluto a fini sportivi, ad altra associazione o società sportiva dilettantistica o ad altro ente con finalità sportive, sentito l'organismo di controllo di cui all'art. 3, comma 190, della L. 662/1996 ove operante, salvo diversa destinazione imposta dalla legge.

### Art. 30 – Controversie

1. Le controversie in materia sportiva sono devolute agli organi di giustizia degli enti di affiliazione, secondo i rispettivi regolamenti.
2. Ogni altra controversia tra i soci, o tra i soci e l'Associazione o i suoi organi, relativa al rapporto associativo e compromettibile per legge, è devoluta a un collegio di tre arbitri. Ciascuna parte nomina un arbitro; il terzo, con funzioni di presidente, è nominato di comune accordo dai primi due o, in mancanza di accordo, dal Presidente del Tribunale di Terni su istanza della parte più diligente. Il collegio decide secondo diritto, con arbitrato rituale.

### Art. 31 – Norme finali e transitorie

1. Per quanto non previsto dal presente statuto si applicano le norme del Codice civile, del D.Lgs. 36/2021, del D.Lgs. 39/2021, le altre norme sugli enti sportivi dilettantistici e sugli enti non commerciali, e le norme degli enti di affiliazione, nonché, in quanto compatibile, l'art. 148 del Testo unico delle imposte sui redditi (D.P.R. 22 dicembre 1986, n. 917).
2. Il primo Consiglio Direttivo e il primo Presidente sono nominati nell'atto costitutivo e restano in carica quattro anni.
